<ul>
<?php dynamic_sidebar();?>
</ul>